//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resources.rc
//
#define IDD_MSGDLG                      101
#define IDR_MENU1                       102
#define IDD_ABOUT                       103
#define IDR_ACCELERATOR1                104
#define IDC_LIST1                       1000
#define IDM_EXIT                        40001
#define IDM_ABOUT                       40002
#define IDM_PAUSE                       40003
#define IDM_PERF_MONITOR                40004
#define IDM_SHADOWS                     40005
#define IDM_TEXTURES                    40006
#define IDM_SAVE_SETTINGS               40007
#define IDM_SINGLE_STEP                 40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
