// openode_UnitTest++.cpp : Defines the entry point for the console application.
//

#include <UnitTest++.h>

int main()
{
    return UnitTest::RunAllTests();
}
