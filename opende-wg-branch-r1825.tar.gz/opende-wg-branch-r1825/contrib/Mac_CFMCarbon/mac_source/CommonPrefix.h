#define TARGET_API_MAC_CARBON 1
#define finite isfinite
#define dNODEBUG 1

// Comment out for single precision
#define PRECISION_DOUBLE 1